<?php
// Load environment variables from .env file (if using dotenv)
require_once __DIR__ . '/../helpers/env.php';

// Define project constants
define('BASE_URL', 'http://localhost/Brahmakumari/');
define('APP_NAME', 'Brahmakumari Management System');

// Database credentials from .env file (or fallback)
$host = getenv('DB_HOST') ?: 'localhost';
$dbname = trim(getenv('DB_NAME') ?: 'brahmakumari_cearsleg_9656'); // Trim to remove spaces
$username = getenv('DB_USER') ?: 'root';
$password = getenv('DB_PASS') ?: '';
$charset = 'utf8mb4';

// Enable error reporting for development (Disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Secure session settings BEFORE starting session
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_cookies', 1);
    ini_set('session.cookie_httponly', 1);
    ini_set('session.cookie_secure', 0); // Set to 1 if using HTTPS
    session_start();
    session_regenerate_id(true);
}


// Database connection using PDO
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=$charset", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    error_log("Database Connection Error: " . $e->getMessage(), 3, __DIR__ . '/../logs/error.log');
    die("Database connection failed. Please check logs.");
}

// Timezone settings
date_default_timezone_set('UTC');

// Security Headers
header("X-Frame-Options: DENY");
header("X-XSS-Protection: 1; mode=block");
header("X-Content-Type-Options: nosniff");
header("Referrer-Policy: no-referrer");
?>
