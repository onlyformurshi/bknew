<?php
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: views/auth/login.php");
    exit;
} else {
    header("Location: views/dashboard/index.php");
    exit;
}
?>
